
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BankAppDB bankAppDB = new BankAppDB();
		
	SavingsAccount[] accountsArr = bankAppDB.getAccountList();
	SavingsAccount account = bankAppDB.findByAccount(2);
	account.printDetails();
	//for(int i=0;i<accountsArr.length;i++){
		//SavingsAccount account = accountsArr[i];
		//System.out.print("AccNo :"+account.accNo);
		//System.out.println("Balance :"+account.balance);
		
	//}
	}
	

}
