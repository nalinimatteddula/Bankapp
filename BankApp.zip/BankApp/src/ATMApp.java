import java.util.Scanner;

public class ATMApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to the ATM Service");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(" Enter Account No:");
		//prompt the user to provide account no:
		
		int accNo = scanner.nextInt();
		
		BankAppDB bankAppDB = new BankAppDB();
		SavingsAccount account = bankAppDB.findByAccount(accNo);
			
			
			  System.out.println("Enter pin :");
			  
			int pin = scanner.nextInt();
			if (account!=null &&account.isPinValid(pin)) {
				System.out.println("Select transaction type: \n 1.Balance Enquiry \n 2. Withdrawal");
				
				int value = scanner.nextInt();
			
			switch (value) {
			case 1: 
			  System.out.println("Balance :"+account.balance);
			break;
			default :
				System.out.println("Invalid selection value");
				break;
			case 2:
				System.out.println("Enter withdrawal amount:");
				int withdrawAmount =scanner.nextInt();
				//boolean result = account.withdrawAmount(pin, withdrawAmount);
				//if (result)
					System.out.println("Please collect the cash");
				break;
			}
			
		}else {
			System.out.println("Account Doesn't exist");
		}
	}

}
