
public class BankAppDB {
   
	SavingsAccount[] accountList = new SavingsAccount[5];
	
	public BankAppDB() {
		for(int i=0; i<accountList.length; ){
			accountList[i] = new SavingsAccount(++i,5000,1234);
		}
	}
		public SavingsAccount[] getAccountList() {
			return accountList;
		}
		
		public SavingsAccount findByAccount(int accNo) {
			for (SavingsAccount savingsAccount : accountList) {
				
				if (savingsAccount.accNo ==accNo) {
					return savingsAccount;
					
				}
				
			}return null;
		}
}


